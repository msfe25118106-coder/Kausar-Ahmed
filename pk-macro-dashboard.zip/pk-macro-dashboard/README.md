# Pakistan Macro Dashboard

Scheduled collector -> docs/data.json -> static dashboard (GitHub Pages).

## Setup
1. Create a GitHub repo and push this folder.
2. Settings > Pages > Source: deploy from branch `main`, folder `/docs`.
3. Settings > Secrets and variables > Actions > New secret: `EASYDATA_API_KEY`.
4. Edit `collector/config.json`: confirm `url_template` against SBP's API docs and replace each `REPLACE_CODE` with a real EasyData series code.
5. Actions tab > "Update dashboard data" > Run workflow. Then it runs every 6 hours (Mon-Sat).

## No API key yet?
Download a series from EasyData as CSV, save as `data/csv/<series_id>.csv` (columns: date,value), commit, run the workflow. Used automatically when the API fails.

## Test locally
`EASYDATA_API_KEY=xxx python collector/collect.py` then open `docs/index.html` via `python -m http.server -d docs`.

## Notes
Never commit the key. Failed series keep their last values and show "stale" with an error banner.
Next modules: auction results, swap premiums, PSX, MoF fiscal data (each as a new function in collect.py).
