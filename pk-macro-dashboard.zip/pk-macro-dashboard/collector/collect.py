"""Fetch series from SBP EasyData (or local CSVs) and write docs/data.json.
Usage: EASYDATA_API_KEY=xxx python collector/collect.py
Fallback: put data/csv/<series_id>.csv (columns: date,value) and it is used if the API is unavailable."""
import csv, json, os, sys, datetime as dt, urllib.request, urllib.error
ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
CFG = json.load(open(os.path.join(ROOT, "collector", "config.json")))
OUT = os.path.join(ROOT, "docs", "data.json")
KEY = os.environ.get("EASYDATA_API_KEY", "")

def num(x):
    try: return float(str(x).replace(",", ""))
    except Exception: return None

def parse(payload):
    """Accepts [[date,value],...], [{date:..,value:..},...], or a dict wrapping either."""
    if isinstance(payload, dict):
        for v in payload.values():
            if isinstance(v, list) and v: payload = v; break
    rows = []
    for it in payload if isinstance(payload, list) else []:
        if isinstance(it, (list, tuple)) and len(it) >= 2: d, v = it[0], it[1]
        elif isinstance(it, dict):
            dk = next((k for k in it if any(s in k.lower() for s in ("date", "period", "obs", "time"))), None)
            vk = next((k for k in it if k != dk and num(it[k]) is not None), None)
            if not dk or not vk: continue
            d, v = it[dk], it[vk]
        else: continue
        v = num(v)
        if v is not None: rows.append([str(d)[:10], v])
    return sorted(rows)

def from_api(code):
    if not KEY or code.startswith("REPLACE"): raise RuntimeError("no API key or placeholder code")
    url = CFG["url_template"].format(code=code, key=KEY)
    with urllib.request.urlopen(urllib.request.Request(url, headers={"User-Agent": "pk-macro-dashboard"}), timeout=60) as r:
        rows = parse(json.load(r))
    if not rows: raise RuntimeError("API returned no parsable rows")
    return rows

def from_csv(sid):
    p = os.path.join(ROOT, "data", "csv", sid + ".csv")
    if not os.path.exists(p): raise RuntimeError("no CSV fallback")
    return sorted([r[0][:10], num(r[1])] for r in csv.reader(open(p)) if len(r) > 1 and num(r[1]) is not None)

old = json.load(open(OUT)) if os.path.exists(OUT) else {"series": {}}
out = {"asOf": dt.datetime.utcnow().isoformat() + "Z", "series": {}, "meta": {}}
cutoff = (dt.date.today() - dt.timedelta(days=CFG["history_days"])).isoformat()
failed = []
for s in CFG["series"]:
    sid, src = s["id"], "EasyData API"
    try: rows = from_api(s["code"])
    except Exception as e:
        try: rows, src = from_csv(sid), "CSV file"
        except Exception as e2:
            rows, src = old["series"].get(sid, []), "stale (kept previous)"
            failed.append(f"{sid}: API {e}; CSV {e2}")
    out["series"][sid] = [r for r in rows if r[0] >= cutoff]
    out["meta"][sid] = {"label": s["label"], "unit": s.get("unit", ""), "group": s.get("group", ""),
                        "source": src, "updated": old.get("meta", {}).get(sid, {}).get("updated") if src.startswith("stale") else out["asOf"]}
out["errors"] = failed
json.dump(out, open(OUT, "w"), separators=(",", ":"))
print("written", OUT)
for f in failed: print("FAILED", f, file=sys.stderr)
sys.exit(1 if failed else 0)
